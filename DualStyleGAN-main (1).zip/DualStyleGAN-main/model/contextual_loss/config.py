# TODO: add supports for L1, L2 etc.
LOSS_TYPES = ['cosine', 'l1', 'l2']
